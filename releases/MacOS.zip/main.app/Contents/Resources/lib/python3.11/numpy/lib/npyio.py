from ._npyio_impl import DataSource, NpzFile, __doc__  # noqa: F401

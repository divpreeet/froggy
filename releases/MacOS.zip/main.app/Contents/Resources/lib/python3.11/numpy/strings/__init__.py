from numpy._core.strings import *
from numpy._core.strings import __all__, __doc__

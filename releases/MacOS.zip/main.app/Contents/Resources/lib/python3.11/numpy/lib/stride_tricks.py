from ._stride_tricks_impl import __doc__, as_strided, sliding_window_view  # noqa: F401
